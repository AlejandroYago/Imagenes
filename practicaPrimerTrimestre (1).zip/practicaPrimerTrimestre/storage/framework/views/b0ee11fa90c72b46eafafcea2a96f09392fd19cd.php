<?php $__env->startSection('contentnavbar'); ?>

<div class="navbar navbar-fixed-top">
    <div class="navbar-inner">
        <div class="container">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                <i class="icon-reorder shaded"></i></a><a class="brand" href="<?php echo e(url('puesto')); ?>">Puesto </a>
            <div class="nav-collapse collapse navbar-inverse-collapse">
                <ul class="nav nav-icons">
                    <li class="active"><a href="#"><i class="icon-envelope"></i></a></li>
                    <li><a href="#"><i class="icon-eye-open"></i></a></li>
                    <li><a href="#"><i class="icon-bar-chart"></i></a></li>
                </ul>
                <form class="navbar-search pull-left input-append" action="#">
                <input type="text" class="span3">
                <button class="btn" type="button">
                    <i class="icon-search"></i>
                </button>
                </form>
                <ul class="nav pull-right">
                    <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown
                        <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Item No. 1</a></li>
                            <li><a href="#">Don't Click</a></li>
                            <li class="divider"></li>
                            <li class="nav-header">Example Header</li>
                            <li><a href="#">A Separated link</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Support </a></li>
                    <li class="nav-user dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="<?php echo e(url('assets/admin/images/user.png')); ?>" class="nav-avatar" />
                        <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Your Profile</a></li>
                            <li><a href="#">Edit Profile</a></li>
                            <li><a href="#">Account Settings</a></li>
                            <li class="divider"></li>
                            <li><a href="#">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.nav-collapse -->
        </div>
    </div>
    <!-- /navbar-inner -->
</div>

<?php $__env->startSection('sidebar'); ?>
<div class="span3">
    <div class="sidebar">
        <ul class="widget widget-menu unstyled">
            <li class="active"><a href="<?php echo e(url('/')); ?>"><i class="menu-icon icon-dashboard"></i>Dashboard
            </a></li>
            <li><a href="<?php echo e(url('puesto')); ?>"><i class="menu-icon icon-bullhorn"></i>Tabla Puestos </a>
            </li>
            <li><a href="<?php echo e(url('puesto')); ?>"><i class="menu-icon icon-bullhorn"></i>Añadir Puestos </a>
            </li>
            <li><a href="message.html"><i class="menu-icon icon-inbox"></i>Inbox <b class="label green pull-right">
                11</b> </a></li>
            <li><a href="task.html"><i class="menu-icon icon-tasks"></i>Tasks <b class="label orange pull-right">
                19</b> </a></li>
        </ul>
        <!--/.widget-nav-->
        
        
        <ul class="widget widget-menu unstyled">
            <li><a href="ui-button-icon.html"><i class="menu-icon icon-bold"></i> Buttons </a></li>
            <li><a href="ui-typography.html"><i class="menu-icon icon-book"></i>Typography </a></li>
            <li><a href="form.html"><i class="menu-icon icon-paste"></i>Forms </a></li>
            <li><a href="table.html"><i class="menu-icon icon-table"></i>Tables </a></li>
            <li><a href="charts.html"><i class="menu-icon icon-bar-chart"></i>Charts </a></li>
        </ul>
        <!--/.widget-nav-->
        <ul class="widget widget-menu unstyled">
            <li><a class="collapsed" data-toggle="collapse" href="#togglePages"><i class="menu-icon icon-cog">
            </i><i class="icon-chevron-down pull-right"></i><i class="icon-chevron-up pull-right">
            </i>More Pages </a>
                <ul id="togglePages" class="collapse unstyled">
                    <li><a href="other-login.html"><i class="icon-inbox"></i>Login </a></li>
                    <li><a href="other-user-profile.html"><i class="icon-inbox"></i>Profile </a></li>
                    <li><a href="other-user-listing.html"><i class="icon-inbox"></i>All Users </a></li>
                </ul>
            </li>
            <li><a href="#"><i class="menu-icon icon-signout"></i>Logout </a></li>
        </ul>
    </div>
    <!--/.sidebar-->
</div>


 <form class="form-horizontal row-fluid" action="<?php echo e(url('puesto')); ?>" method="post" >
     <?php echo csrf_field(); ?>
     <?php echo method_field('post'); ?>
     <?php if(Session::has('message')): ?>
    <div class="alert alert-<?php echo e(session()->get('type')); ?>" role="alert" style="text-align:center;">
        <?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
     <div class="alert alert-danger">
     <ul>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><!--Esto es por si al introducirlo, he introducido varias cosas mal, pues que me alerte de todas-->
     <li><?php echo e($error); ?></li>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
     </div>
    <?php endif; ?>
    
	<div class="control-group"  style="margin-top:220px">
	    <br>
		<label class="control-label" for="basicinput" >Nombre Puesto:</label>
		<div class="controls">
			<input type="text" id="basicinput" name="nombre" placeholder="Introduce el nombre del puesto" class="span8" style="margin-left:30px;">
		</div>
		<br>
		<label class="control-label" for="basicinput">Sueldo Minimo:</label>
		<div class="controls">
			<input type="number" step="0.01" id="basicinput" name="minimo" placeholder="Ejemplo: 5" class="span8" style="margin-left:30px">
		</div>
		<br>
	    <label class="control-label" for="basicinput">Sueldo Maximo:</label>
		<div class="controls">
			<input type="number" step="0.01" id="basicinput" name="maximo" placeholder="Ejemplo: 10000" class="span8" style="margin-left:30px">
		</div>
		<br>
		<br>
	    <label class="control-label" for="basicinput"></label>
		<div class="controls">
			<input type="submit" class="btn"  value="Añadir" style="margin-left:30px; width:66%">
		</div>
	</div>
	
</form>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/practicaPrimerTrimestre/resources/views/puesto/create.blade.php ENDPATH**/ ?>